import os

PROJECT_NAME = "name"

#SQLALCHEMY_DATABASE_URI = os.getenv("DATABASE_URL")
SQLALCHEMY_DATABASE_URI ="postgresql+psycopg2://djaoued:fckyou@localhost:5433/djaoued"

API_V1_STR = "/api/v1"
