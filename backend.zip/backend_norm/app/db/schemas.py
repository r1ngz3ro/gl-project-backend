from pydantic import BaseModel, EmailStr
from typing import Optional, List
import typing as t

class UserBase(BaseModel):
    email: EmailStr
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    is_active: bool = True
    is_superuser: bool = False

class UserCreate(UserBase):
    password: str

class UserInDB(UserBase):
    id: int
    user_type: str

    class Config:
        orm_mode = True

class TeacherCreate(UserCreate):
    subject: Optional[str] = None

class CourseBase(BaseModel):
    name: str
    date: Optional[str] = "2021-01-01"
class CourseCreate(CourseBase):
    teacher_id: Optional[int] = None

class CourseInDB(CourseBase):
    id: int
    teacher_id: Optional[int] = None

    class Config:
        orm_mode = True

class CourseEnrollmentCreate(BaseModel):
    course_id: int
    student_id: int
    grade: Optional[str] = None
