from sqlalchemy import Column, Integer, String, Boolean, Date, ForeignKey, CheckConstraint
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base
from typing import Optional, List

Base = declarative_base()

class User(Base):
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, nullable=False)
    first_name = Column(String)
    last_name = Column(String)
    hashed_password = Column(String, nullable=False)
    is_active = Column(Boolean, default=True)
    is_superuser = Column(Boolean, default=False)
    user_type = Column(String, nullable=False)
    
    __mapper_args__ = {
        'polymorphic_identity': 'user',
        'polymorphic_on': user_type
    }

class Teacher(User):
    __mapper_args__ = {
        'polymorphic_identity': 'teacher'
    }
    subject = Column(String)
    courses = relationship("Course", back_populates="teacher")

class Student(User):
    __mapper_args__ = {
        'polymorphic_identity': 'student'
    }
    enrollments = relationship("CourseEnrollment", back_populates="student")

class Course(Base):
    __tablename__ = 'courses'
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    teacher_id = Column(Integer, ForeignKey('users.id'), nullable=True)
    date = Column(String, nullable=True)
    
    teacher = relationship("Teacher", back_populates="courses")
    enrollments = relationship("CourseEnrollment", back_populates="course")

class CourseEnrollment(Base):
    __tablename__ = 'course_enrollments'
    
    course_id = Column(Integer, ForeignKey('courses.id'), primary_key=True)
    student_id = Column(Integer, ForeignKey('users.id'), primary_key=True)
    grade = Column(String)
    
    course = relationship("Course", back_populates="enrollments")
    student = relationship("Student", back_populates="enrollments")

