from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional
import app.db.models as models
import app.db.schemas as schemas
from app.db.session import get_db


users_router=app = APIRouter()


# User CRUD
@app.post("/users/", response_model=schemas.UserInDB)
def create_user(user: schemas.UserCreate, db: Session = Depends(get_db)):
    db_user = models.User(
        email=user.email,
        first_name=user.first_name,
        last_name=user.last_name,
        hashed_password=get_password_hash(user.password),  # Implement password hashing
        is_active=user.is_active,
        is_superuser=user.is_superuser,
        user_type='user'
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

@app.get("/users/", response_model=List[schemas.UserInDB])
def read_users(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    users = db.query(models.User).offset(skip).limit(limit).all()
    return users

@app.get("/users/{user_id}", response_model=schemas.UserInDB)
def read_user(user_id: int, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    return user

# Teacher CRUD
@app.post("/teachers/", response_model=schemas.UserInDB)
def create_teacher(teacher: schemas.TeacherCreate, db: Session = Depends(get_db)):
    db_teacher = models.Teacher(
        email=teacher.email,
        first_name=teacher.first_name,
        last_name=teacher.last_name,
        hashed_password=get_password_hash(teacher.password),
        subject=teacher.subject,
        is_active=teacher.is_active,
        is_superuser=teacher.is_superuser,
        user_type='teacher'
    )
    db.add(db_teacher)
    db.commit()
    db.refresh(db_teacher)
    return db_teacher

@app.get("/teachers/", response_model=List[schemas.UserInDB])
def read_teachers(db: Session = Depends(get_db)):
    teachers = db.query(models.Teacher).all()
    return teachers

# Course CRUD
@app.post("/courses/", response_model=schemas.CourseInDB)
def create_course(course: schemas.CourseCreate, db: Session = Depends(get_db)):
    db_course = models.Course(
        name=course.name,
        date='1111',
        teacher_id=course.teacher_id
    )
    db.add(db_course)
    db.commit()
    db.refresh(db_course)
    return db_course

@app.get("/courses/", response_model=List[schemas.CourseInDB])
def read_courses(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    courses = db.query(models.Course).offset(skip).limit(limit).all()
    return courses

# Course Enrollment CRUD
@app.post("/enrollments/")
def create_enrollment(enrollment: schemas.CourseEnrollmentCreate, db: Session = Depends(get_db)):
    db_enrollment = models.CourseEnrollment(
        course_id=enrollment.course_id,
        student_id=enrollment.student_id,
        grade=enrollment.grade
    )
    db.add(db_enrollment)
    db.commit()
    db.refresh(db_enrollment)
    return db_enrollment

@app.post("/courses/{course_id}/enroll")
def enroll_student(
    course_id: int,
    student_id: int,
    db: Session = Depends(get_db)
):
    # Check if course exists
    course = db.query(models.Course).filter(models.Course.id == course_id).first()
    if not course:
        raise HTTPException(status_code=404, detail="Course not found")

    # Check if student exists
    student = db.query(models.Student).filter(models.Student.id == student_id).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")

    # Check if already enrolled
    existing_enrollment = db.query(models.CourseEnrollment).filter(
        models.CourseEnrollment.course_id == course_id,
        models.CourseEnrollment.student_id == student_id
    ).first()
    if existing_enrollment:
        raise HTTPException(status_code=400, detail="Student already enrolled")

    # Create new enrollment
    enrollment = models.CourseEnrollment(
        course_id=course_id,
        student_id=student_id
    )
    db.add(enrollment)
    db.commit()
    db.refresh(enrollment)
    return {"detail": "Student enrolled successfully"}

@app.get("/enrollments/")
def read_enrollments(course_id: Optional[int] = None, student_id: Optional[int] = None, db: Session = Depends(get_db)):
    query = db.query(models.CourseEnrollment)
    if course_id:
        query = query.filter(models.CourseEnrollment.course_id == course_id)
    if student_id:
        query = query.filter(models.CourseEnrollment.student_id == student_id)
    return query.all()

